<template>
  <section id="closing-part" class="bg-light sort-center pt-5" style="min-height: 100vh;">
            <div class="h1 bg-dark p-4 text-white w-100 text-center text-shadow-2-gray">
                Closing
            </div>
            <img src="../../image/thinking.jpg" class="w-50"/>
            <div class="mt-1 mb-3 text-center">
                <h2>저는 항상 생각하고 고민합니다.</h2>
                <div class="w-100 p-2 ml-auto mr-auto" style="font-size: 12px;">
                    현재에 안주하지 않고 끝없이 발전하려 노력합니다.<br/>
                    사람들이 세상의 변화를 만들어내듯, 저 자신도 항상 변화하고 발전하려 하고 있습니다.<br/>
                    이런 저의 열정으로 더 큰 변화를 불러오고, 새로운 가치를 창출하여 더 좋은 세상이 될 수 있도록 하고 싶습니다.<br/>
                    감사합니다.<br/><br/>
                    - Inbae Kang
                </div>
            </div>
        </section>
</template>

<script>
export default {

}
</script>

<style>

</style>