<template>
  <section id="language-part" class="pt-5" style="min-height: 100vh;">
            <div class="h1 bg-dark p-4 text-white w-100 text-center text-shadow-2-gray">
                Language Skill
            </div>
        <ul class="w-75 ml-auto mr-auto mt-5 skill-list">
            <li class="list-group-item d-flex aligin-items-center p-4">
                <div class="w-25">C</div>
                <div class="progress w-50 m-auto">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" 
                            role="progressbar" 
                            style="width: 80%"
                            aria-valuenow="80"
                            aria-valuemin="0"
                            aria-valuemax="100">
                    </div>
                </div>
                <div class="w-24 text-center">80%</div>
            </li>
            <li class="list-group-item d-flex aligin-items-center p-4">
                <div class="w-25">C++</div>
                <div class="progress w-50 m-auto">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" 
                            role="progressbar" 
                            style="width: 90%"
                            aria-valuenow="90"
                            aria-valuemin="0"
                            aria-valuemax="100">
                    </div>
                </div>
                <div class="w-24 text-center">90%</div>
            </li>
            <li class="list-group-item d-flex aligin-items-center p-4">
                <div class="w-25">JAVA</div>
                <div class="progress w-50 m-auto">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" 
                            role="progressbar" 
                            style="width: 85%"
                            aria-valuenow="85"
                            aria-valuemin="0"
                            aria-valuemax="100">
                    </div>
                </div>
                <div class="w-24 text-center">85%</div>
            </li>
            <li class="list-group-item d-flex aligin-items-center p-4">
                <div class="w-25">Javascript</div>
                <div class="progress w-50 m-auto">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" 
                            role="progressbar" 
                            style="width: 70%"
                            aria-valuenow="70"
                            aria-valuemin="0"
                            aria-valuemax="100">
                    </div>
                </div>
                <div class="w-24 text-center">70%</div>
            </li>
            <li class="list-group-item d-flex aligin-items-center p-4">
                <div class="w-25">Python</div>
                <div class="progress w-50 m-auto">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" 
                            role="progressbar" 
                            style="width: 85%"
                            aria-valuenow="85"
                            aria-valuemin="0"
                            aria-valuemax="100">
                    </div>
                </div>
                <div class="w-24 text-center">85%</div>
            </li>
        </ul>   
        </section>
</template>

<script>
export default {

}
</script>

<style>

</style>