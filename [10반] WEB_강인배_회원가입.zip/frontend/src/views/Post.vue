<template>
  <div>
      게시글 작성 페이지 입니다.
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>